﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Collections;
using System.Data;

namespace RandomNumbers
{
    class Program
    {
        Random random = new Random();
        static void Main(string[] args)
        {
            bool stop = false;
            while (!stop)
            {
                Console.WriteLine("Enter the range between which random numbers are to be generated for eg:- 1 , 59");
                string[] range = Console.ReadLine().Split(',');
                Console.WriteLine("Enter the number of random numbers to be generated");
                int numberOfRandomNumbers = Convert.ToInt32(Console.ReadLine());

                ArrayList randomNumberList = new Program().GenerateRandomNumbers(Convert.ToInt32(range[0]), Convert.ToInt32(range[1]), numberOfRandomNumbers);

                // new Program().CreateTableToMatch(randomNumberList, Convert.ToInt32(range[0]), Convert.ToInt32(range[1]));

                DataTable resultantTable = new Program().GetTableValues(randomNumberList, new Program().CreateTableToMatch(randomNumberList, Convert.ToInt32(range[0]), Convert.ToInt32(range[1])));
                Console.WriteLine("");
                Console.WriteLine("Values from the table are:-");
                foreach (DataRow rowValue in resultantTable.Rows)
                {
                    Console.WriteLine(rowValue["Number"] + "," + rowValue["SomeValue"]);
                }
               
                Console.WriteLine("Do you want to continue ? Y/N");
                stop = Console.ReadLine() == "Y" ? false : true;
            }
        }

        public ArrayList GenerateRandomNumbers(int seed,int maxValue, int numberOfRandomNumbers)
        {
            ArrayList randomNumbersList = new ArrayList();
         
            for (int i = 0; i < numberOfRandomNumbers; i++)
            {
                randomNumbersList.Add(random.Next(seed,maxValue));
            }
            return randomNumbersList;
        }
        public DataTable CreateTableToMatch(ArrayList numbersToMatch,int initialValue,int maxRecords)
        {
            DataTable datatableToMatchValues = new DataTable();
            datatableToMatchValues.Columns.Add("Number");
            datatableToMatchValues.Columns.Add("SomeValue");
            for (int i = initialValue; i <= maxRecords; i++)
            {
               DataRow newDataRow = datatableToMatchValues.NewRow();
               newDataRow["Number"] = i;
               newDataRow["SomeValue"] = "value" + i;
               datatableToMatchValues.Rows.Add(newDataRow);
               datatableToMatchValues.AcceptChanges();
            }
            return datatableToMatchValues;
        }
        public DataTable GetTableValues(ArrayList numbersToMatch, DataTable TableToMatch)
        {
            DataTable resultsTable = new DataTable();
            resultsTable.Columns.Add("Number");
            resultsTable.Columns.Add("SomeValue");
            foreach (int number in numbersToMatch)
            {
                // DataRow resultsRow = resultsTable.NewRow();
                DataRow[] selectedRows = TableToMatch.Select("Number = '" + number + "'");
                foreach (DataRow resulantRow in selectedRows)
                {
                    resultsTable.ImportRow(resulantRow);
                    resultsTable.AcceptChanges();
                }
            }
            return resultsTable;
        }
    }
}
