﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Collections;

namespace SubsetSum
{
    public class SubsetsSum
    {

        public bool IsListOfNumbersEmpty(string listOfNumbers)
        {
            return (listOfNumbers == string.Empty);
        }

        public string GetSetsOfNumbers(string[] numbersArray, int givensum)
        {
            string sets = "";
            int sum = 0;
            int constant = 0; int counter = 0;
            for (int i = 0; i < numbersArray.Length; i++)
            {
                constant = Convert.ToInt32(numbersArray[i]);
                for (int j = i + 1; j < numbersArray.Length; j++)
                {   //2
                    string[] tempArray = new string[numbersArray.Length];
                    counter = j;
                    sum = constant;
                    int tempArrayIndex=0;
                    while (counter < numbersArray.Length)
                    {
                        sum += Convert.ToInt32(numbersArray[counter]);
                        tempArray[tempArrayIndex] = numbersArray[counter];
                        if (sum == givensum)
                        {
                            int otherconst = counter;
                            while(tempArrayIndex>=0)
                            {
                                sets += tempArray[tempArrayIndex]+",";
                                tempArrayIndex--;
                            }
                            sets += numbersArray[i] + ";";
                        }
                        tempArrayIndex++;
                        counter++;
                    }
                }
            }
            return sets;
        }
        public string[] GetSortedListOfNumbers(string numbersList)
        {
            numbersList = numbersList.LastIndexOf(",") == numbersList.Length-1?numbersList.Remove(numbersList.Length - 1):numbersList;
            string[] numbersListArr = numbersList.Split(',');
            for (int i = 0; i < numbersListArr.Length; i++)
                for (int j = i + 1; j < numbersListArr.Length; j++)
                {
                    if (Convert.ToInt32(numbersListArr[i]) > Convert.ToInt32(numbersListArr[j]))
                    {
                        string constant = numbersListArr[j];
                        numbersListArr[j] = numbersListArr[i];
                        numbersListArr[i] = constant;
                    }
                }
            return numbersListArr;
        }
    }
}
