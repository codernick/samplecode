﻿using System;
using System.Linq;
using System.Text;
using System.Collections.Generic;

namespace SubsetSum
{
   public class Program
    {
       static void Main(string[] args)
       {
           SubsetsSum subsetSum = new SubsetsSum();
           Console.WriteLine("Please enter the Total Sum:");
           string sum = Console.ReadLine();
           Console.WriteLine("Please enter a comma separated list of Numbers:");
           string numbers = Console.ReadLine();
           bool value =  subsetSum.IsListOfNumbersEmpty(numbers);
           string[] sortedNumbers = subsetSum.GetSortedListOfNumbers(numbers);
           string set = subsetSum.GetSetsOfNumbers(sortedNumbers, Convert.ToInt32(sum));
           set = set== string.Empty ? "No combination matches" : "The required sets are:-\n"+set;
           Console.WriteLine(set);
           Console.ReadLine();
       }
    }
}
